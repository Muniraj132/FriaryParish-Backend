  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/dist/css/adminlte.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/dist/css/style.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/toastr/toastr.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/bootstrap-switch\css\bootstrap3/bootstrap-switch.css">

  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/plugins/dropzone/dropzone.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.48.4/codemirror.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.48.4/theme/base16-dark.css">

  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
  .select2-selection__choice{
    background-color: black !important;
  }
</style><?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>
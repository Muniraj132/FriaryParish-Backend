

<?php $__env->startSection('title'); ?>
<?php echo e(__('main.Media')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e(__('main.Media')); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?php echo e(__('main.Home')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('main.Media')); ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="infinite-scroll">
                        <div class="scroll-content">
                        <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id = $media->id;
                            $media = $media->getMedia('default')->first();
                        ?>
                            <?php if($id!=1): ?>
                            <div class="thumbnail">
                                <a href="<?php echo e(route('admin.media.show',$id)); ?>">
                                    <img id="<?php echo e($id); ?>" src="<?php echo e($media->getUrl('thumb')); ?>">
                                </a>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($medias->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </div><!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/media/index.blade.php ENDPATH**/ ?>
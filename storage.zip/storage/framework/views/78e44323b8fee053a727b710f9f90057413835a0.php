 <?php $__env->startSection('title'); ?> <?php echo e(__('main.Dashboard')); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container">
        <div class="row mt-3">
            <!-- User Card -->
            <!-- User Count Card -->
            <div class="col-md-3">
                <div class="card bg-primary-gradient text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-users fa-3x"></i>
                            </div>
                            <div class="text-right">
                                <h5 class="card-title">Users</h5>
                                <br> 
                                
                                <strong><?php echo e($usercount); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Product Card -->
            <div class="col-md-3">
                <div class="card bg-info-gradient text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-newspaper fa-3x"></i>

                            </div>
                            <div class="text-right">
                                <h5 class="card-title">News letters</h5>
                                <br> 
                                
                                <strong><?php echo e($updates); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Card (Replace with your data) -->
            <div class="col-md-3">
                <div class="card bg-warning-gradient text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-chart-bar fa-3x"></i>
                                
                            </div>
                            <div class="text-right">
                                <h5 class="card-title">Upcoming Eveents</h5>
                                <br>    
                                
                                <strong><?php echo e($services); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Card (Replace with your data) -->
            <div class="col-md-3">
                <div class="card bg-danger-gradient text-white shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                
                                <i class="fas fa-address-book fa-3x"></i>

                            </div>
                            <div class="text-right">
                                <h5 class="card-title">Contact Request</h5>
                                
                                <br> 
                                <strong><?php echo e($contactrequest); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <br>
        <div class="content">
            <div class="container-fluid">
                <div class="card shadow">
                    <div class="card-header">
                        <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-success btn-sm"><?php echo e(__('main.Add New')); ?></a>
                        <a href="<?php echo e(route('admin.user.trash')); ?>" class="btn btn-warning btn-sm float-right"><i class="fas fa-trash-alt"></i><?php echo e(__('main.Recycle')); ?></a>
                    </div>
                    <div class="card-body">
                        <table id="table1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('main.Name')); ?></th>
                                    <th><?php echo e(__('main.E-mail')); ?></th>
                                    <th><?php echo e(__('main.Role')); ?></th>
                                    <th><?php echo e(__('main.Statu')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.user.edit',$user->id)); ?>" title="<?php echo e(__('main.Edit')); ?>" class="btn btn-primary btn-xs"><i class="fas fa-pencil-alt"></i></a>
                                        <a href="<?php echo e(route('admin.user.delete',$user->id)); ?>" onclick="validate(<?php echo e($user->id); ?>)" title="<?php echo e(__('main.Delete')); ?>" class="btn btn-danger btn-xs"><i class="far fa-times-circle"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('script'); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/home.blade.php ENDPATH**/ ?>
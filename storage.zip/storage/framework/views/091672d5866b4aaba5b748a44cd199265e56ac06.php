

<?php $__env->startSection('title'); ?>
<?php echo e(__('main.Slides')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e(__('main.Slides')); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('main.Slides')); ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('admin.slide.create')); ?>" class="btn btn-success btn-sm"><?php echo e(__('main.Add New')); ?></a>
                </div>
            </div>
            <div class="row" id="maincontent">
              <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-3" data-id="<?php echo e($slide->id); ?>">
                  <div class="card">
                      <img src="<?php echo e(asset('slideimages/'.$slide->bg)); ?>" alt="" class="w-100">
                      <p class="text-center slidetag"><b><?php echo e($slide->title); ?></b></p>
                      <p class="text-center slidetag"><?php echo e($slide->content); ?></p>
                      <div class="text-right">
                          <a href="<?php echo e(route('admin.slide.edit',$slide->id)); ?>" title="<?php echo e(__('main.Edit')); ?>" class="btn btn-primary btn-xs"><i class="fas fa-pencil-alt"></i></a>
                          <form id="delete_<?php echo e($slide->id); ?>" action="<?php echo e(route('admin.slide.destroy',$slide->id)); ?>" method="post" class="d-inline">
                              <?php echo method_field('DELETE'); ?>
                              <?php echo csrf_field(); ?>
                              <a href="javascript:void(0)" onclick="validate(<?php echo e($slide->id); ?>)" title="<?php echo e(__('main.Delete')); ?>" class="btn btn-danger btn-xs"><i class="far fa-times-circle"></i></a>
                          </form>
                      </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
  $(document).ready(function() {
        // Enable sorting for the maincontent container
        $("#maincontent").sortable({
            items: "> .col-md-3",
            cursor: 'move',
            opacity: 0.6,
            update: function(event, ui) {
                // Get the sorted items
                var sortedItems = $(this).sortable("toArray", { attribute: 'data-id' });

                // Send an AJAX request to update the order
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('admin.slide.updateOrder')); ?>",
                    data: {
                        sortedItems: sortedItems,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        console.log(response);
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/slides/index.blade.php ENDPATH**/ ?>
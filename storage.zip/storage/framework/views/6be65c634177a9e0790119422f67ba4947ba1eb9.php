
<style>
  ul li a{
    color: white !important;
  }
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: #4691CE;">
    <!-- Brand Logo -->
 
    <a href="<?php echo e(route('admin.home')); ?>" class="brand-link" style="text-align:justify; color:white;">
    <img src="<?php echo e(asset('admin')); ?>/img/leftlogo.png" alt="HasPanel Logo" class="brand-image img-circle elevation-3" >
     <strong class="brand-text font-weight-light" style=""> <span style="font-weight: 700;">St. Anthony’s Parish</span></strong>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('admin.home')); ?>" class="nav-link <?php if(Request::segment(2)=="home"): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p><?php echo e(__('main.Dashboard')); ?></p>
            </a>
          </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.slide.index')); ?>" class="nav-link <?php if(Request::segment(2)=="slide"): ?> active <?php endif; ?>">
                  <i class="fas fa-expand nav-icon"></i>
                <p><?php echo e(__('main.Slides')); ?></p>
              </a>
            </li>
            <li class="nav-item has-treeview <?php if(Request::segment(2)=="news_events"  || Request::segment(3)=='news_events'): ?> menu-open <?php endif; ?> ">
              <a href="<?php echo e(route('admin.news_events.index')); ?>" class="nav-link <?php if(Request::segment(2)=="news_events" || Request::segment(3)=='features'): ?> active <?php endif; ?>">
                <i class="fas fa-calendar nav-icon"></i>
                  <p>
                      <?php echo e(__('main.ourfeature')); ?>

                      <i class="right fas fa-angle-left"></i>
                  </p>
              </a>
              <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="news_events"): ?> display:block; <?php endif; ?>">
                  <li class="nav-item">
                      <a href="<?php echo e(route('admin.news_events.category')); ?>" class="nav-link <?php if(Request::segment(3)=="news_events" || Request::segment(2)=="category"): ?> active <?php endif; ?>">
                          <ion-icon name="return-down-forward-outline"></ion-icon>
                          <p><?php echo e(__('main.Categories')); ?></p>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="<?php echo e(route('admin.news_events.index')); ?>" class="nav-link <?php if(Request::segment(2)=="news_events" && Request::segment(3)!="create"): ?> active <?php endif; ?>">
                          <ion-icon name="return-down-forward-outline"></ion-icon>
                          <p><?php echo e(__('main.Allourfeature')); ?></p>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="<?php echo e(route('admin.news_events.create')); ?>" class="nav-link <?php if(Request::segment(2)=="news_events" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                          <ion-icon name="return-down-forward-outline"></ion-icon>
                          <p><?php echo e(__('main.Addourfeature')); ?></p>
                      </a>
                  </li>
              </ul>
          </li>
          <li class="nav-item has-treeview <?php if(Request::segment(2)=="update" || Request::segment(3)=='update'): ?> menu-open <?php endif; ?> ">
            <a href="<?php echo e(route('admin.update.index')); ?>" class="nav-link <?php if(Request::segment(2)=="update" || Request::segment(3)=='update'): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-book"></i>
                <p>
                    <?php echo e(__('main.update')); ?>

                    <i class="right fas fa-angle-left"></i>
                </p>
            </a>
            <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="update"): ?> display:block; <?php endif; ?>">
                <li class
                ="nav-item">
                    <a href="<?php echo e(route('admin.update.category')); ?>" class="nav-link <?php if(Request::segment(3)=="update" || Request::segment(2)=="category"): ?> active <?php endif; ?>">
                        <ion-icon name="return-down-forward-outline"></ion-icon>
                        <p><?php echo e(__('main.Categories')); ?></p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.update.index')); ?>" class="nav-link <?php if(Request::segment(2)=="update" && Request::segment(3)!="create"): ?> active <?php endif; ?>">
                        <ion-icon name="return-down-forward-outline"></ion-icon>
                        <p><?php echo e(__('main.Allupdate')); ?></p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.update.create')); ?>" class="nav-link <?php if(Request::segment(2)=="update" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                        <ion-icon name="return-down-forward-outline"></ion-icon>
                        <p><?php echo e(__('main.Addupdate')); ?></p>
                    </a>
                </li>
            </ul>
        </li>
        <li class="nav-item has-treeview <?php if(Request::segment(2)=="ourteams" || Request::segment(3)== "ourteams"): ?> menu-open <?php endif; ?>">
          <a href="<?php echo e(route('admin.ourteams.index')); ?>" class="nav-link <?php if(Request::segment(2)=="ourteams" || Request::segment(3)== "ourteams"): ?> active <?php endif; ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>
              <?php echo e(__('main.ourteams')); ?>

              
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="ourteams"): ?> display:block; <?php endif; ?>">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.ourteams.category')); ?>" class="nav-link <?php if(Request::segment(3)=="ourteams" || Request::segment(2)=="category"): ?> active <?php endif; ?>">
                <ion-icon name="return-down-forward-outline"></ion-icon>
                <p><?php echo e(__('main.Categories')); ?></p>
              </a>
            </li>
            <li class="nav-item"> 
              <a href="<?php echo e(route('admin.ourteams.index')); ?>" class="nav-link <?php if(Request::segment(2)=="ourteams" && Request::segment(3)!="create"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.Allourteam')); ?></p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.ourteams.create')); ?>" class="nav-link <?php if(Request::segment(2)=="ourteams" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.AddNewourteam')); ?></p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item has-treeview <?php if(Request::segment(2)=="resource" || Request::segment(3)=="message"): ?> menu-open <?php endif; ?>">
          <a href="<?php echo e(route('admin.resource.index')); ?>" class="nav-link <?php if(Request::segment(2)=="resource" ||  Request::segment(3)=="message"): ?> active <?php endif; ?>">
            <i class="fas fa-comment nav-icon"></i>
  
              <p>
                  <?php echo e(__('main.resources')); ?>

              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="resource"): ?> display:block; <?php endif; ?>">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.message.category')); ?>" class="nav-link <?php if(Request::segment(3)=="message" && Request::segment(2)=="category"): ?> active <?php endif; ?>">
                <ion-icon name="return-down-forward-outline"></ion-icon>
                <p><?php echo e(__('main.Categories')); ?></p>
              </a>
            </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.resource.index')); ?>" class="nav-link <?php if(Request::segment(2)=="resource" && Request::segment(3)!="create"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.allresources')); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.resource.create')); ?>" class="nav-link <?php if(Request::segment(2)=="resource" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.addresources')); ?></p>
                </a>
              </li>
          </ul>
        </li>
        <li class="nav-item has-treeview <?php if(Request::segment(2)=="page"): ?> menu-open <?php endif; ?>">
          <a href="<?php echo e(route('admin.page.index')); ?>" class="nav-link <?php if(Request::segment(2)=="page"): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-copy"></i>
            <p>
              <?php echo e(__('main.Pages')); ?>

              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="page"): ?> display:block; <?php endif; ?>">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.page.index')); ?>" class="nav-link <?php if(Request::segment(2)=="page"&& Request::segment(3)!="create"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.All Pages')); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.page.create')); ?>" class="nav-link <?php if(Request::segment(2)=="page" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.Add New')); ?></p>
                </a>
              </li>
          </ul>
        </li>
          <li class="nav-item has-treeview <?php if(Request::segment(2)=="mainmenu" || Request::segment(2)=="submenu" || Request::segment(2)== "childsubmenu" || Request::segment(2)== "subchildsubmenu"): ?>  menu-open <?php endif; ?>">
            <a href="<?php echo e(route('admin.mainmenu.index')); ?>" class="nav-link <?php if(Request::segment(2)=="mainmenu" || Request::segment(2)=="submenu"): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-plus-circle"></i>
              <p>
                <?php echo e(__('main.Menus')); ?>

                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="media"): ?> display:block; <?php endif; ?>">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.mainmenu.index')); ?>" class="nav-link <?php if(Request::segment(2)=="mainmenu"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.mainmenu')); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.submenu.index')); ?>" class="nav-link <?php if(Request::segment(2)=="submenu"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.submenu')); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.childsubmenu.index')); ?>" class="nav-link <?php if(Request::segment(2)=="childsubmenu"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.childsubmenu')); ?></p>
                </a>
              </li>
              
            </ul>
          </li>

          <li class="nav-item has-treeview <?php if(Request::segment(2)=="media"): ?> menu-open <?php endif; ?>">
            <a href="<?php echo e(route('admin.media.index')); ?>" class="nav-link <?php if(Request::segment(2)=="media"): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-photo-video"></i>
              <p>
                <?php echo e(__('main.Media')); ?>

                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="media"): ?> display:block; <?php endif; ?>">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.media.index')); ?>" class="nav-link <?php if(Request::segment(2)=="media" && Request::segment(3)!="create"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.All Media')); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.media.create')); ?>" class="nav-link <?php if(Request::segment(2)=="media" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.Upload')); ?></p>
                </a>
              </li>
            </ul>
          </li>
          
          
          
         
          <li class="nav-item has-treeview <?php if(Request::segment(2)=="gallery" || Request::segment(3)== "gallery"): ?> menu-open <?php endif; ?>">
            <a href="<?php echo e(route('admin.gallery.index')); ?>" class="nav-link <?php if(Request::segment(2)=="gallery" || Request::segment(3)== "gallery"): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-image"></i>
              <p>
                <?php echo e(__('main.Gallery')); ?>

                
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="gallery"): ?> display:block; <?php endif; ?>">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.gallery.category')); ?>" class="nav-link <?php if(Request::segment(3)=="gallery" || Request::segment(2)=="category"): ?> active <?php endif; ?>">
                  <ion-icon name="return-down-forward-outline"></ion-icon>
                  <p><?php echo e(__('main.Categories')); ?></p>
                </a>
              </li>
              <li class="nav-item"> 
                <a href="<?php echo e(route('admin.gallery.index')); ?>" class="nav-link <?php if(Request::segment(2)=="gallery" && Request::segment(3)!="create"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.All Images')); ?></p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.gallery.create')); ?>" class="nav-link <?php if(Request::segment(2)=="gallery" && Request::segment(3)=="create"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.addgallery')); ?></p>
                </a>
              </li>
            </ul>
          </li>
          
          
          <li class="nav-item">
            <a href="<?php echo e(route('admin.contact.index')); ?>" class="nav-link <?php if(Request::segment(2)=="contact"): ?> active <?php endif; ?>">
                <i class="fas fa-phone nav-icon"></i>
              <p><?php echo e(__('main.Contact Request')); ?></p>
            </a>
          </li>

          

          
        <li class="nav-item has-treeview <?php if(Request::segment(2)=="option" ): ?> menu-open <?php endif; ?>">
            <a href="<?php echo e(route('admin.option.index')); ?>" class="nav-link <?php if(Request::segment(2)=="option"): ?> active <?php endif; ?>">
                <i class=" nav-icon fas fa-cog"></i>
                <p>
                    <?php echo e(__('main.Options')); ?>

                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview" style="<?php if(Request::segment(2)=="option"): ?> display:block; <?php endif; ?>">
               <li class="nav-item">
                  <a href="<?php echo e(route('admin.option.contact')); ?>" class="nav-link <?php if(Request::segment(2)=="option" && Request::segment(3)=="contact"): ?> active <?php endif; ?>">
                    <ion-icon name="return-down-forward-outline"></ion-icon>
                    <p><?php echo e(__('main.Contact Information')); ?></p>
                  </a>
                </li>
            </ul>
          </li>
         

          <li class="nav-item">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); this.closest('form').submit();">
                <i class="nav-icon fas fa-power-off"></i>
                <?php echo e(__('main.Logout')); ?>

              </a>
            </form>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/layouts/menu.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title'); ?>
    <?php echo e(__('main.ourfeature')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h4 class="m-0 text-dark"><?php echo e(__('main.ourfeature')); ?></h4>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('main.ourfeature')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('admin.news_events.create')); ?>"
                            class="btn btn-success btn-sm"><?php echo e(__('main.Add New')); ?></a>
                        <a href="<?php echo e(route('admin.news_events.trash')); ?>" class="btn btn-warning btn-sm float-right"><i
                                class="fas fa-trash-alt"></i><?php echo e(__('main.Recycle')); ?></a>
                    </div>
                    <div class="card-body">
                        <table id="table1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <tr>
                                        <th><?php echo e(__('main.id')); ?></th>
                                        <th><?php echo e(__('main.Title')); ?></th>
                                        <th><?php echo e(__('main.Category')); ?></th>
                                        <th><?php echo e(__('main.Statu')); ?></th>
                                        <th><?php echo e(__('main.Creation Date')); ?></th>
                                        <th><?php echo e(__('main.Action')); ?></th>
                                    </tr>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $newsevents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($event->title); ?></td>
                                        <td><?php echo e($event->getCategory->title); ?></td>
                                        <td><input class="switch" type="checkbox" name="my-checkbox"
                                                data-id="<?php echo e($event->id); ?>" <?php if($event->status == 1): ?> checked <?php endif; ?>
                                                data-toggle="toggle" data-size="mini"
                                                data-on="<?php echo e(__('main.Published')); ?>" data-off="<?php echo e(__('main.Draft')); ?>"
                                                data-onstyle="success" data-offstyle="danger"></td>
                                                <td><?php echo e($event->formatDate($event->created_at)); ?> </td>
                                        <td>
                                            
                                            <a href="<?php echo e(route('admin.news_events.edit', $event->id)); ?>"
                                                title="<?php echo e(__('main.Edit')); ?>" class="btn btn-primary btn-xs"><i
                                                    class="fas fa-pencil-alt"></i></a>
                                            <a href="<?php echo e(route('admin.news_events.delete', $event->id)); ?>"
                                                onclick="confirmDelete( event, <?php echo e($event->id); ?>)" title="<?php echo e(__('main.Delete')); ?>"
                                                class="btn btn-danger btn-xs"><i class="far fa-times-circle"></i></a>
                                        </td>
                                    </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div><!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

$('.switch').change(function() {
    var id = $(this).attr('data-id');
    var status = $(this).prop('checked') == true? 1 : 0;
   $.ajax({
       url: "<?php echo e(route('admin.news_events.switch')); ?>",
       type: "POST",
       data: {
           "_token": "<?php echo e(csrf_token()); ?>",
           "id": id,
           "status": status
       },
       success: function(data) {
           console.log(data);
       }
   })
})
        // $('.switch').change(function() {

        //     id = $(this).attr('data-id');
        //     status = $(this).prop('checked');
        //     $.get("<?php echo e(route('admin.news_events.switch')); ?>", {
        //         id: id,
        //         status: status
        //     })
        // })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/newsevent/index.blade.php ENDPATH**/ ?>
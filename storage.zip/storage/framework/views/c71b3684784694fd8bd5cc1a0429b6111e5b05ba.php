<style>
  .dropdown-item{
    background-color:#4691CE


;
  }
  .dropdown-item:focus, .dropdown-item:hover{
    background-color: black;
  }
</style>
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" style="color: #856156;"></i></a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link mt-2"  data-toggle="dropdown" href="#">
          <i class="far fa-bell" style="color: #856156;"></i>
          <span class="badge badge-warning navbar-badge">0</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-header"><?php echo e(__("main.No Notification")); ?></span>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button"><img src="<?php echo e(asset('admin')); ?>/img/mypic.png" style="width: 30px;" class="img-circle elevation-2" alt="User Image"></a>
      </li>
    </ul>
  </nav>
<?php /**PATH C:\xampp\htdocs\friaryparish\FriaryParish-Backend\resources\views/admin/layouts/navbar.blade.php ENDPATH**/ ?>